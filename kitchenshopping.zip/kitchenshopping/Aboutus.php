
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Shop it to me</title>
<link rel="stylesheet" href="css/style.css" type="text/css" />

</head>

<body>

<div class="main-wrapper"> 
  <!----------------{ Header }---------------->
  <div class="header">
    <div class="top-part">
      <div class="top-inner-part">

       <div class="login-area"> Hello, Guest Welcome you can <a href="index.php"> Home </a> <a href="Aboutus.php"> AboutUs </a> <a href="Contactus.php"> ContactUs </a><a href="login.php"> Log in </a> or <a href="frmreg.php"> create an account </a>
          <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    <div class="logo-area">
      <div class="logo"> <a href="#"> <img src="images/logo.png" /></a> </div>
      <div class="search-bar"> <div class="clearfix"></div>  <div class="cart-btns">  <div class="clearfix"></div>  </div> </div>
      <div class="clearfix"></div>
 
    </div>
    <div class="shadow"><img src="images/shadow.png" /></div>
   
  </div>
  
  
  <!----------------{ Middle }---------------->
  <div class="middle">
    <div class="middle-inner"> 
      <!-------- evt-search-wrap -------->
      <div class="pro-cart-page">
       
        

        <div class="clearfix"></div>
             
                    <div class="product-box">
   FOUNDER MEMBERS
Mr. Chhotu SharmaMr. Chhotu Sharma Founder of CS Group
Mr. Chhotu Sharma is the founder of CS Group. He is a Microsoft Certified Software Developer and has been training students and IT professionals in different Microsoft technologies for the past 12 years. He is well known as "The Guru of Microsoft Technologies" due to his experience and knowledge. For his excellent work in the field of education, he has been conferred with the title of "Himachal Gaurav" by Ex. Chief Minister, Sh. Prem Kumar Dhumal in the year 2007. His students have been picked up by Fortune 500 companies including Microsoft, Accenture, TCS, Infosys and others. In the year 2009, he established CS Soft Solutions Pvt. Ltd, a company offering complete IT solutions in multifarious IT applications. His penchant for excellence at professional as well as at personal front, backed by a sincere and an honest approach towards life are the basic reasons for the success of the ventures he has launched and actively developed. These qualities of sincerity and honesty easily percolate among his students, ensuring their success in future lives too.

Mrs. Shalini SharmaMrs. Shalini Sharma Founder of CS Group
Mrs. Shalini Sharma, the Director of CS Soft Solutions Pvt. Ltd is also an adept teacher at CS Infotech. She is an embodiment of immense patience, optimism and bears a sharp analytical acumen coupled with excellent People Management skills. Sincerity, simplicity and honesty have been her perennial hallmarks. Having trained thousands of students over the vast teaching experience of 7 years, she meticulously imparts technical training to her wards with endeavour to make them fully equipped in dealing with various requirements of the IT industry, in their careers. Never afraid to take risks, she is well known for her management skills. With her firm approach of doing business, the organisation has witnessed a staggering growth over just a short span.


                    </div>
                
      </div>
      
      <!-------- End-evt-search-wrap -------->
      <div class="evt-detail">
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
  <!----------------{ End Middle }----------------> 
  
  <!----------------{ Footer }---------------->
  <div class="footer">
    <div class="footer-inner">
 
      
      <div class="clearfix"></div>
      <p> © Copyright 2019 CS Infotech. All rights reserved. </p>
    </div>
  </div>
  <!----------------{ End Footer }----------------> 
</div>
<!-----------------------------{ End Main Wrapper }----------------------------->
</body>
</html>


